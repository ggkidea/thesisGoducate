<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Camp Goducate</title>
  <link rel="stylesheet" href="style.css">
</head>
<body style="background-color:#33475b">
  <!-- Header Section -->
  <header>
    <div class="container head_container flex_space">
      <div class="logo"><img src="images/logo.webp" alt="Logo"></div>
      <nav>
        <ul id="nav-menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="gallery.php">Activities</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="booking.php">Book Now</a></li>
        </ul>
        <div class="hambuger" id="hamburger-menu">
          <div class="bar"></div>
          <div class="bar"></div>
          <div class="bar"></div>
        </div>
      </nav>
    </div>
  </header>

  <!-- Home Section -->
  <section class="home" id="home">
    <div class="content">
      <div class="text">
        <h1>Welcome to Camp Goducate Iloilo</h1>
        <p>Relax and enjoy your stay at Camp Goducate.</p>
        <a href="booking.php"><button>Book Now</button></a>
      </div>
      <div class="image"><img src="images/bckgrnd.png" alt="Home Image" class="slide"></div>
    </div>
    <div class="image_item">
      <img src="images/bckgrnd.png" alt="" class="slide active" onclick="setBackground('bckgrnd.png')">
      <img src="images/A11.jpg" alt="" class="slide" onclick="setBackground('images/A11.jpg')">
      <img src="images/A12.jpg" alt="" class="slide" onclick="setBackground('images/A12.jpg')">
      <img src="images/A13.jpg" alt="" class="slide" onclick="setBackground('images/A13.jpg')">
      <img src="images/A14.jpg" alt="" class="slide" onclick="setBackground('images/A14.jpg')">
    </div>
  </section>
  <script src="script.js"></script>
</body>
</html>