<?php

$DBcon = new mysqli("localhost", "root", "", "goducateDB");

if ($DBcon->connect_errno) {
    die ("Error: ". $DBcon->connect_error);
}
?>