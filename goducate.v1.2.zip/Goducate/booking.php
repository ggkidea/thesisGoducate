<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resort Booking - Book Your Stay</title>
  <link rel="stylesheet" href="style.css">
</head>
<body style="background-color:powderblue;">
    <header>
        <div class="container head_container flex_space">
          <div class="logo"><img src="images/logo.webp" alt="Logo"></div>
          <nav>
          <ul id="nav-menu">
              <li><a href="index.php">Home</a></li>
              <li><a href="about.php">About Us</a></li>
              <li><a href="gallery.php">Activities</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li><a href="booking.php">Book Now</a></li>
            </ul>
            <div class="hamburger" id="hamburger-menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
            </div>
          </nav>
        </div>
      </header>

<?php 
session_start();

if (isset($_SESSION['userSession']) != "") {
    header("Location: success.php");
}

require_once 'dbconnect.php';

if (isset($_POST['btn-signup'])) {
    $customerName = strip_tags($_POST['name']);
    $customerEmail = strip_tags($_POST['email']);
    $customerNumber = strip_tags($_POST['number']);
    $checkIn = strip_tags($_POST['checkIn']);
    $checkOut = strip_tags($_POST['checkOut']);
    $adults = strip_tags($_POST['adults']);
    $children = strip_tags($_POST['children']);

    $customerName = $DBcon->real_escape_string($customerName);
    $customerEmail = $DBcon->real_escape_string($customerEmail);
    $customerNumber = $DBcon->real_escape_string($customerNumber);
    $checkIn = $DBcon->real_escape_string($checkIn);
    $checkOut = $DBcon->real_escape_string($checkOut);
    $adults = $DBcon->real_escape_string($adults);
    $children = $DBcon->real_escape_string($children);

    $check_email = $DBcon->query("SELECT customerEmail FROM Customers WHERE customerEmail='$customerEmail'");
    $check_name = $DBcon->query("SELECT customerName FROM Customers WHERE customerName='$customerName'");

    $count = $check_email->num_rows + $check_name->num_rows;

    if ($count == 0) {
        $query = "INSERT INTO Customers(customerName, customerEmail, customerNumber, checkIn, checkOut, adults, children) VALUES('$customerName', '$customerEmail', '$customerNumber', '$checkIn', '$checkOut', '$adults', '$children')";

        if ($DBcon->query($query)) {
            $msg = "<div><h3 style=\"color: grey\">&nbsp; Successfully Booked!</h3></div>";
        } else {
            $msg = "<div><h3 style=\"color: grey\">&nbsp; Error while booking!</h3></div>";
        }
    }

    $DBcon->close();
}
?>

<section class="book top" id="booking">
    <div class="container">
      <div class="heading">
        <h5>RAISING THE RELAXATION TO THE HIGHEST LEVEL</h5>
        <h2>Book Your Stay</h2>
      </div>
      <form action="booking.php" method="post">
        <div class="grid">
          <div class="box"><label>Name</label><input type="text" placeholder="Enter Name" name="name" required></div>
          <div class="box"><label>Email</label><input type="email" placeholder="Enter Email" name="email" required></div>
          <div class="box"><label>Phone Number</label><input type="text" placeholder="Enter Number" name="number" required></div>
          <div class="box"><label>Check-in</label><input type="date" name="checkIn" required></div>
          <div class="box"><label>Check-out</label><input type="date" name="checkOut" required></div>
          <div class="box"><label>Adults</label><input type="number" placeholder="Enter Number" name="adults" required></div>
          <div class="box"><label>Children</label><input type="number" placeholder="Enter Number" name="children" required></div>
        </div>
        <button style="width: 25%; height: 3%; background-color: #808080; color: #fff;" type="submit" class="btn btn-default" name="btn-signup">
          <span></span>&nbsp; Submit Booking
        </button>
        <br>
      </form>
    </div>
</section>
</body>
</html>
