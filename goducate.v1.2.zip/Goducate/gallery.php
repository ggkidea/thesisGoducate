<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resort Booking - Gallery</title>
  <link rel="stylesheet" href="style.css">
</head>
<body style="background-color:powderblue;">
    <header>
        <div class="container head_container flex_space">
          <div class="logo"><img src="images/logo.webp" alt="Logo"></div>
          <nav>
          <ul id="nav-menu">
              <li><a href="index.php" >Home</a></li>
              <li><a href="about.php">About Us</a></li>
              <li><a href="gallery.php">Activities</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li><a href="booking.php">Book Now</a></li>
            </ul>
            <div class="hambuger" id="hamburger-menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
            </div>
          </nav>
        </div>
      </header>
  <!-- Gallery Section -->
  <section class="gallery top" id="gallery">
    <div class="container">
      <div class="heading_top flex1">
        <div class="heading">
          <h5>JOIN US AND ENJOY OUR WONDERFUL ACTIVITIES</h5>
          <h2>Our Activities</h2>
        </div>
      </div>
      <div class="content grid">
        <div class="box"><div class="img"><img src="images/A1.jpg" alt="Gallery Image 1"></div></div>
        <div class="box"><div class="img"><img src="images/A2.jpg" alt="Gallery Image 2"></div></div>
        <div class="box"><div class="img"><img src="images/A3.jpg" alt="Gallery Image 3"></div></div>
        <div class="box"><div class="img"><img src="images/A4.jpg" alt="Gallery Image 4"></div></div>
        <div class="box"><div class="img"><img src="images/A5.jpg" alt="Gallery Image 5"></div></div>
        <div class="box"><div class="img"><img src="images/A7.jpg" alt="Gallery Image 6"></div></div>
        <div class="box"><div class="img"><img src="images/A8.jpg" alt="Gallery Image 6"></div></div>
        <div class="box"><div class="img"><img src="images/A9.jpg" alt="Gallery Image 6"></div></div>
        <div class="box"><div class="img"><img src="images/A10.jpg" alt="Gallery Image 6"></div></div>
      </div>
    </div>
  </section>
</body>
</html>
