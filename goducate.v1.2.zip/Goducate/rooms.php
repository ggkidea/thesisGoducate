<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resort Booking - Rooms</title>
  <link rel="stylesheet" href="style.css">
</head>
<body style="background-color:powderblue;">
    <header>
        <div class="container head_container flex_space">
          <div class="logo"><img src="images/logo.webp" alt="Logo"></div>
          <nav>
          <ul id="nav-menu">
              <li><a href="index.php" >Home</a></li>
              <li><a href="about.php">About Us</a></li>
              <li><a href="gallery.php">Activities</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li><a href="booking.php">Book Now</a></li>
            </ul>
            <div class="hambuger" id="hamburger-menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
            </div>
          </nav>
        </div>
      </header>
  <!-- Rooms Section -->
  <section class="rooms top" id="rooms">
    <div class="container">
      <div class="heading">
        <h5>RAISING THE RELAXATION TO THE HIGHEST LEVEL</h5>
        <h2>Our Rooms</h2>
      </div>
      <div class="content grid">
        <div class="box">
          <div class="img"><img src="images/js.jpg" alt="Jungle Huts"></div>
          <div class="text"><h3>Jungle Huts</h3><p>₱2000 /per unit per night</p></div>
        </div>
        <div class="box">
          <div class="img"><img src="images/sr.jpg" alt="Family Rooms"></div>
          <div class="text"><h3>Family Rooms</h3><p>₱2500 /per unit per night</p></div>
        </div>
        <div class="box">
          <div class="img"><img src="images/cy.jpg" alt="Cottages"></div>
          <div class="text"><h3>Cottages</h3><p>₱1500 /per unit per night</p></div>
        </div>
        <div class="box">
          <div class="img"><img src="images/jm.jpg" alt="Dormitories"></div>
          <div class="text"><h3>Dormitories</h3><p>₱1000 /per unit per night</p></div>
        </div>
      </div>
    </div>
  </section>
</body>
</html>
