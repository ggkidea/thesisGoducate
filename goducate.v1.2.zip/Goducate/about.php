<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resort Booking - About</title>
  <link rel="stylesheet" href="style.css">
</head>
<body style="background-color:powderblue;">
    <header>
        <div class="container head_container flex_space">
          <div class="logo"><img src="images/logo.webp" alt="Logo"></div>
          <nav>
            <ul id="nav-menu">
              <li><a href="index.php" >Home</a></li>
              <li><a href="about.php">About Us</a></li>
              <li><a href="gallery.php">Activities</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li><a href="booking.php">Book Now</a></li>
            </ul>
            <div class="hambuger" id="hamburger-menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
            </div>
          </nav>
        </div>
      </header>
  <!-- About Section -->
  <section class="about top" id="about">
    <div class="container flex">
      <div class="left">
        <div class="heading">
          <h5>RAISING THE RELAXATION TO THE HIGHEST LEVEL</h5>
          <h2>Welcome to our Resort</h2>
        </div>
        <p>Welcome to our serene and luxurious resort, a haven for relaxation and rejuvenation. Nestled in the heart of nature, our resort offers a perfect blend of comfort and adventure.</p>
        <p>Our resort is dedicated to providing a memorable stay, complete with top-notch amenities, friendly service, and a variety of activities to suit all preferences.</p>
        <a href="booking.html"><button>Book Your Stay</button></a>
      </div>
      <div class="right">
        <div class="img">
          <img src="images/abouts.jpg" alt="About Us">
        </div>
      </div>
    </div>
  </section>
</body>
</html>
