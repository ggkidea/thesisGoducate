function setBackground(image) {
    document.getElementById('home').style.backgroundImage = `url('${image}')`;
}
