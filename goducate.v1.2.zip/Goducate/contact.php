<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resort Booking - Contact</title>
  <link rel="stylesheet" href="style.css">
</head>
<body style="background-color:powderblue;">
    <header>
        <div class="container head_container flex_space">
          <div class="logo"><img src="images/logo.webp" alt="Logo"></div>
          <nav>
          <ul id="nav-menu">
              <li><a href="index.php" >Home</a></li>
              <li><a href="about.php">About Us</a></li>
              <li><a href="gallery.php">Activities</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li><a href="booking.php">Book Now</a></li>
            </ul>
            <div class="hambuger" id="hamburger-menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
            </div>
          </nav>
        </div>
      </header>
  <!-- Contact Section -->
  <section class="contact top" id="contact">
    <div class="container flex">
      <div class="left">
        <div class="heading">
          <h5>RAISING THE RELAXATION TO THE HIGHEST LEVEL</h5>
          <h2>Contact Us</h2>
        </div>
        <p>If you have any questions, feel free to reach out to us. Our team is here to assist you and ensure your stay is memorable.</p>
        <div class="details grid">
          <div class="box">
            <h4>ADDRESS:</h4>
            <p>60 Grant St. Pine Hill, NY 12465</p>
          </div>
          <div class="box">
            <h4>EMAIL:</h4>
            <p>info@resort.com</p>
          </div>
          <div class="box">
            <h4>PHONE:</h4>
            <p>(123) 456-7890</p>
          </div>
        </div>
      </div>
      <div class="right">
        <form action="">
          <div class="box"><label>Name</label><input type="text" placeholder="Enter Name"></div>
          <div class="box"><label>Email</label><input type="email" placeholder="Enter Email"></div>
          <div class="box"><label>Phone Number</label><input type="text" placeholder="Enter Number"></div>
          <div class="box"><label>Message</label><textarea cols="30" rows="10" placeholder="Enter Message"></textarea></div>
          <button>Submit</button>
        </form>
      </div>
    </div>
  </section>
</body>
</html>
