<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Resort Booking - Membership Registration</title>
  <link rel="stylesheet" href="style.css">
</head>
<body style="background-color:powderblue;">
    <header>
        <div class="container head_container flex_space">
          <div class="logo"><img src="images/logo.webp" alt="Logo"></div>
          <nav>
          <ul id="nav-menu">
              <li><a href="index.php" >Home</a></li>
              <li><a href="about.php">About Us</a></li>
              <li><a href="gallery.php">Activities</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li><a href="booking.php">Book Now</a></li>
            </ul>
            <div class="hambuger" id="hamburger-menu">
              <div class="bar"></div>
              <div class="bar"></div>
              <div class="bar"></div>
            </div>
          </nav>
        </div>
      </header>
  <!-- Registration Section -->
  <section class="register top" id="registration">
    <div class="container">
      <div class="heading">
        <h5>RAISING THE RELAXATION TO THE HIGHEST LEVEL</h5>
        <h2>Membership Registration</h2>
      </div>
      <form action="">
        <div class="grid">
          <div class="box"><label>Name</label><input type="text" placeholder="Enter Name"></div>
          <div class="box"><label>Gender</label><input type="text" placeholder="Enter Gender"></div>
          <div class="box"><label>Email</label><input type="email" placeholder="Enter Email"></div>
          <div class="box"><label>Phone Number</label><input type="text" placeholder="Enter Number"></div>
          <div class="box"><label>Birthday</label><input type="date" placeholder="Enter Birthday"></div>
          <div class="box"><label>Age</label><input type="number" placeholder="Enter Age"></div>
          <div class="box"><label>Address</label><input type="text" placeholder="Enter Address"></div>
          <div class="box"><label>City</label><input type="text" placeholder="Enter City"></div>
          <div class="box"><label>Region</label><input type="text" placeholder="Enter Region"></div>
          <div class="box"><label>Zip Code</label><input type="number" placeholder="Enter Zip"></div>
          <div class="box"><label>Country</label><input type="text" placeholder="Enter Country"></div>
        </div>
        <button>Submit Registration</button>
      </form>
    </div>
  </section>
</body>
</html>
